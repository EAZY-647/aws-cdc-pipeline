import psycopg2
import mysql.connector
import time
import os

# --- 1. CONFIGURATION ---
# (Update these with your actual passwords!)
PG_CONFIG = {
    'dbname': 'postgres', 
    'user': 'postgres', 
    'password': 'Pr@tyush26',  # <--- CHANGE THIS
    'host': 'localhost', 
    'port': '5432'
}

MYSQL_CONFIG = {
    'database': 'testdb', 
    'user': 'root', 
    'password': 'Pr@tyush26',     # <--- CHANGE THIS
    'host': 'localhost'
}

STATE_FILE = "last_sync_state.txt"

# --- 2. HELPER FUNCTIONS ---
def get_last_sync_time():
    """Reads the last sync timestamp from a text file."""
    if not os.path.exists(STATE_FILE):
        return "1970-01-01 00:00:00"  # Default to beginning of time
    with open(STATE_FILE, "r") as f:
        return f.read().strip()

def save_last_sync_time(timestamp):
    """Saves the new watermark so we don't re-copy old data."""
    with open(STATE_FILE, "w") as f:
        f.write(str(timestamp))

def sync_data():
    last_sync = get_last_sync_time()
    print(f"--- Checking for changes after: {last_sync} ---")

    # Connect to Source (Postgres)
    try:
        pg_conn = psycopg2.connect(**PG_CONFIG)
        pg_cur = pg_conn.cursor()
        
        # The Secret Sauce: Only get rows that have changed recently
        query = "SELECT id, name, email, updated_at FROM users WHERE updated_at > %s ORDER BY updated_at ASC"
        pg_cur.execute(query, (last_sync,))
        rows = pg_cur.fetchall()
        
        pg_conn.close()
    except Exception as e:
        print(f"Postgres Connection Error: {e}")
        return

    if not rows:
        print("No new changes found.")
        return

    print(f"Found {len(rows)} updates! Pushing to MySQL...")

    # Connect to Destination (MySQL)
    try:
        my_conn = mysql.connector.connect(**MYSQL_CONFIG)
        my_cur = my_conn.cursor()

        new_watermark = last_sync

        for row in rows:
            user_id, name, email, updated_at = row
            
            # UPSERT Logic: If ID exists, update it. If not, insert it.
            sql = """
            INSERT INTO users (id, name, email, updated_at) 
            VALUES (%s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE 
                name = VALUES(name), 
                email = VALUES(email), 
                updated_at = VALUES(updated_at)
            """
            my_cur.execute(sql, (user_id, name, email, updated_at))
            new_watermark = updated_at

        my_conn.commit()
        my_conn.close()
        
        # Save the new state only after success
        save_last_sync_time(new_watermark)
        print("Sync successful.")

    except Exception as e:
        print(f"MySQL Connection Error: {e}")

# --- 3. THE MAIN LOOP ---
if __name__ == "__main__":
    print("🚀 Autoloader Started. Press Ctrl+C to stop.")
    while True:
        sync_data()
        time.sleep(5) # Wait 5 seconds